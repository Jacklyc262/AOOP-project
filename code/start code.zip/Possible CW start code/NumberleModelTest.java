import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class NumberleModelTest {

    INumberleModel model = new NumberleModel();
    /*
    TEST 1
    This scenario is to test the situation where the user guesses the target equation correctly for the
    first time when the random switch, equation display switch, and equation verification switch are all set to true.
    This scenario also tested the effectiveness of the equality display switch and the equality verification switch

    @ invariant model.getRemainingAttempts() >= 0 && model.getRemainingAttempts() <=6
    @ requires model != null && model.getTargetNumber() != null;
    @ requires model.MAX_ATTEMPTS == model.getRemainingAttempts();
    @ requires !model.isGameWon();
    @ ensures model.isGameOver();
     */
    @Test
    public void NumberleModelTest_Success() {
        /* one attempt and won*/
        model.setRandFlag(true);
        model.setTestFlag(true);
        model.setValidFlag(true);

        model.startNewGame();
        /* initialize conditions*/
        assertNotNull("Target number is null!",model.getTargetNumber());
        assertEquals("max attempts should be initialized",model.MAX_ATTEMPTS,model.getRemainingAttempts());
        assertFalse("The status of gameWon should be false",model.isGameWon());

        /*correct input*/
        //simulate the user guessing the equation correctly at once
        //Directly use the output of the getTargetNumber() method as user input
        String targetEq = model.getTargetNumber();
        //Because TestFlag is true, targetEq is a valid equation.
        // And if ValidFlag is true, entering a valid equation processInput() will return true.
        assertTrue("This is not a valid input",model.processInput(targetEq));
        assertTrue("The status should be true",model.isGameWon());
        assertTrue("The status should be true",model.isGameOver());

        /*check equation color*/
        //ResChars represents the match between the user's input equation and the target equation.
        //0 means not match, 1 means match the right position, 2 means match the wrong position
        String resChars = model.getResChars().toString();
        StringBuilder expectRes = new StringBuilder();
        for(int i=0;i<targetEq.length();i++){
            expectRes.append('1');
        }
        assertEquals("All characters should be the right place.",resChars,expectRes.toString());

        /*check same, diff */
        //Check if the "characters that appear but are in the correct position"
        // and "characters that appear but are in the wrong position" are correct
        StringBuilder sameChars = model.getSameCharsc();
        for(int i=0;i<targetEq.length();i++){
            assertNotEquals("The character should be marked in the right position",sameChars.indexOf(Character.toString(targetEq.charAt(i))),-1);
        }
        StringBuilder diffChars = model.getDiffCharsc();
        assertEquals(diffChars.length(),0);
    }

    /*
    TEST 2
    This scenario is to test the situation where the user inputs an incorrect equation as an attempt
    and fails to guess the target equation 6 times,
    resulting in the game losing, with the ValidFlag switch turned off.
    Requirement:
    When the equation random switch is turned off, the target equation is the default equation
    When the equality check switch is turned off,
    invalid or incorrect input of the equation is also considered a valid attempt.

    @ invariant model.getRemainingAttempts() >= 0 && model.getRemainingAttempts() <=6
    @ requires model != null && model.getTargetNumber() != null;
    @ requires model.MAX_ATTEMPTS == model.getRemainingAttempts();
    @ requires !model.isGameWon();
    @ ensures model.isGameOver();
     */
    @Test
    public void NumberleModelTest_LoseValidOff() {
        model.setRandFlag(false);
        model.setValidFlag(false);
        model.setTestFlag(true);


        model.startNewGame();
        /* initialize conditions*/
        assertNotNull("Target number is null!",model.getTargetNumber());
        assertEquals("max attempts should be initialized",model.MAX_ATTEMPTS,model.getRemainingAttempts());
        assertFalse("The status of gameWon should be false",model.isGameWon());

        /*check target*/
        String targetEq = model.getTargetNumber();
        /* the default target eq = "1*3+4=7"*/
        assertEquals(targetEq,"1*3+4=7");

        /*wrong input1*/
        String input1 ="1+2+3=4";
        assertTrue("This is a valid input",model.processInput(input1));
        assertEquals("current attempt should be 5",model.MAX_ATTEMPTS-1,model.getRemainingAttempts());
        assertFalse("The status should be false",model.isGameWon());
        assertFalse("The status should be false",model.isGameOver());


        /*check equation color*/
        //ResChars represents the match between the user's input equation and the target equation.
        //0 means not match, 1 means match the right position, 2 means match the wrong position
        String resChars = model.getResChars().toString();
        //The resChars corresponding to "1+2+3=4" should be "1001212"
        String expectRes = "1001212";
        assertEquals(resChars,expectRes);

        /*check same, diff */
        //Check if the "characters that appear but are in the correct position"
        // and "characters that appear but are in the wrong position" are correct
        String targetSame = "1+=";
        StringBuilder sameChars = model.getSameCharsc();
        assertEquals(sameChars.toString(),targetSame);
        StringBuilder diffChars = model.getDiffCharsc();
        String targetdiff = "34";
        assertEquals(diffChars.toString(),targetdiff);

        /*valid input*/
        String input2 ="1+3+4=8";
        assertTrue("This is a valid input",model.processInput(input2));
        assertEquals("current attempt should be 4",model.MAX_ATTEMPTS-2,model.getRemainingAttempts());


        /*check equation color*/
        resChars = model.getResChars().toString();
        expectRes = "1011110";
        assertEquals(resChars,expectRes);

        /*check same, diff */
        targetSame = "1+=34";
        sameChars = model.getSameCharsc();
        assertEquals(sameChars.toString(),targetSame);
        diffChars = model.getDiffCharsc();
        targetdiff = "";
        assertEquals(diffChars.toString(),targetdiff);

        /*wrong input*/
        String input3 ="1+2+3=1";
        assertTrue("This is a valid input",model.processInput(input3));
        assertEquals("current attempt should be 3",model.MAX_ATTEMPTS-3,model.getRemainingAttempts());

        resChars = model.getResChars().toString();
        expectRes = "1001210";
        assertEquals(resChars,expectRes);

        /*check same, diff */
        targetSame = "1+=34";
        sameChars = model.getSameCharsc();
        assertEquals(sameChars.toString(),targetSame);
        diffChars = model.getDiffCharsc();
        targetdiff = "";
        assertEquals(diffChars.toString(),targetdiff);

        String input4 ="1+2+3=1";
        assertTrue("This is a valid input",model.processInput(input4));
        assertEquals("current attempt should be 2",model.MAX_ATTEMPTS-4,model.getRemainingAttempts());

        String input5 ="1+2+3=1";
        assertTrue("This is a valid input",model.processInput(input5));
        assertEquals("current attempt should be 1",model.MAX_ATTEMPTS-5,model.getRemainingAttempts());

        String input6 ="1+2+3=1";
        assertTrue("This is a valid input",model.processInput(input6));
        assertEquals("current attempt should be 0",model.MAX_ATTEMPTS-6,model.getRemainingAttempts());

        /*check same, diff */
        targetSame = "1+=34";
        sameChars = model.getSameCharsc();
        assertEquals(sameChars.toString(),targetSame);
        diffChars = model.getDiffCharsc();
        targetdiff = "";
        assertEquals(diffChars.toString(),targetdiff);

        assertFalse("The status should be false",model.isGameWon());
        assertTrue("The status should be True",model.isGameOver());
    }

    /*
    TEST 3
    This scenario is to test various erroneous inputs under the condition that the ValidFlag switch is turned on.
    A total of 7 different types of error equations were tested.
    Requirement: When the equality check switch is turned on, invalid or incorrect input will not be counted as a valid attempt,
    and the number of attempts will not change.
    The set of correctly guessed characters and characters that appear but are not in the correct position should also be empty.

    @ invariant model.getRemainingAttempts() >= 0 && model.getRemainingAttempts() <=6
    @ requires model != null && model.getTargetNumber() != null;
    @ requires model.MAX_ATTEMPTS == model.getRemainingAttempts();
    @ requires !model.isGameWon();
    @ ensures model.MAX_ATTEMPTS == model.getRemainingAttempts();
    @ ensures !model.isGameWon();
    @ ensures !model.isGameOver();
     */
    @Test
    public void NumberleModelTest_ErrorValidOn() {
        model.setRandFlag(false);
        /* the target eq = "1*3+4=7"*/
        model.setValidFlag(true);
        model.setTestFlag(false);


        model.startNewGame();
        /* initialize conditions*/
        assertNotNull("Target number is null!",model.getTargetNumber());
        assertEquals("max attempts should be initialized",model.MAX_ATTEMPTS,model.getRemainingAttempts());
        assertFalse("The status of gameWon should be false",model.isGameWon());

        /*check target*/
        // test the closing status of the equation display switch, getTargetNumber() should return "*********"
        String targetEq = model.getTargetNumber();
        assertNotEquals(targetEq,"1*3+4=7");

        /*wrong input1*/
        String input1 ="1+2+3=4";
        assertFalse("This is not a valid input",model.processInput(input1));
        assertEquals("Incorrect error message","left side doesn't equal right side!",model.getErrmsg());
        assertEquals("current attempt should be 6",model.MAX_ATTEMPTS,model.getRemainingAttempts());
        assertFalse("The status should be false",model.isGameWon());
        assertFalse("The status should be false",model.isGameOver());


        /*wrong input2*/
        //Test: Input equation with incorrect length
        String input2 ="5+2=7";
        assertFalse("This is not a valid input",model.processInput(input2));
        assertEquals("Incorrect error message","invalid length!",model.getErrmsg());
        assertEquals("current attempt should be 6",model.MAX_ATTEMPTS,model.getRemainingAttempts());
        assertFalse("The status should be false",model.isGameWon());
        assertFalse("The status should be false",model.isGameOver());

        /*wrong input3*/
        //Test: Input equation with More than one equals
        String input3 ="3*4==12";
        assertFalse("This is not a valid input",model.processInput(input3));
        assertEquals("Incorrect error message","More than one equals sign in the expression.",model.getErrmsg());
        assertEquals("current attempt should be 6",model.MAX_ATTEMPTS,model.getRemainingAttempts());
        assertFalse("The status should be false",model.isGameWon());
        assertFalse("The status should be false",model.isGameOver());

        /*wrong input4*/
        //Test: Input equation with Invalid letter
        String input4 ="abcdefg";
        assertFalse("This is not a valid input",model.processInput(input4));
        assertEquals("Incorrect error message","Invalid letter in the expression.",model.getErrmsg());
        assertEquals("current attempt should be 6",model.MAX_ATTEMPTS,model.getRemainingAttempts());
        assertFalse("The status should be false",model.isGameWon());
        assertFalse("The status should be false",model.isGameOver());

        /*wrong input5*/
        //Test: Input equation with No equals sign in the expression.
        String input5 ="1234567";
        assertFalse("This is not a valid input",model.processInput(input5));
        assertEquals("Incorrect error message","No equals sign in the expression.",model.getErrmsg());
        assertEquals("current attempt should be 6",model.MAX_ATTEMPTS,model.getRemainingAttempts());
        assertFalse("The status should be false",model.isGameWon());
        assertFalse("The status should be false",model.isGameOver());

        /*wrong input6*/
        //Test: Input equation with Division by zero.
        String input6 ="3/0+4=4";
        assertFalse("This is not a valid input",model.processInput(input6));
        assertEquals("Incorrect error message","Division by zero is not allowed.",model.getErrmsg());
        assertEquals("current attempt should be 6",model.MAX_ATTEMPTS,model.getRemainingAttempts());
        assertFalse("The status should be false",model.isGameWon());
        assertFalse("The status should be false",model.isGameOver());

        /*wrong input7*/
        //Test: Input equation with invalid expression.
        String input7 ="11++22=";
        assertFalse("This is not a valid input",model.processInput(input7));
        assertEquals("Incorrect error message","Invalid expression format.",model.getErrmsg());
        assertEquals("current attempt should be 6",model.MAX_ATTEMPTS,model.getRemainingAttempts());
        assertFalse("The status should be false",model.isGameWon());
        assertFalse("The status should be false",model.isGameOver());

        /*check equation color*/
        assertNull(model.getResChars());

        /*check same, diff */
        String targetSame = "";
        StringBuilder sameChars = model.getSameCharsc();
        assertEquals(sameChars.toString(),targetSame);
        StringBuilder diffChars = model.getDiffCharsc();
        String targetdiff = "";
        assertEquals(diffChars.toString(),targetdiff);

        assertEquals("max attempts should be initialized",model.MAX_ATTEMPTS,model.getRemainingAttempts());
        assertFalse("The status of gameWon should be false",model.isGameWon());
        assertFalse("The status should be false",model.isGameOver());
    }



}

// NumberleController.java
public class NumberleController {
    private INumberleModel model;
    private NumberleView view;

    public NumberleController(INumberleModel model) {
        this.model = model;
    }

    public void setView(NumberleView view) {
        this.view = view;
    }

    public void processInput(String input) {
        assert input.length() == getTargetWord().length():"Input have different lengths";
        model.processInput(input);
    }

    public boolean isGameOver() {
        return model.isGameOver();
    }

    public boolean isGameWon() {
        return model.isGameWon();
    }

    public String getTargetWord() {
        return model.getTargetNumber();
    }

    public StringBuilder getCurrentGuess() {
        return model.getCurrentGuess();
    }

    public int getRemainingAttempts() {
        return model.getRemainingAttempts();
    }

    public void startNewGame() {
        model.startNewGame();
    }

    public StringBuilder getSameCharsc() {
        return model.getSameCharsc();
    }

    public StringBuilder getDiffCharsc() {
        return model.getDiffCharsc();
    }
    public StringBuilder getResChars() {
        return model.getResChars();
    }

    public String getErrMsg() {
        return model.getErrmsg();
    }

    public void setRandFlag(boolean flag){
        model.setRandFlag(flag);
    }
    public void setTestFlag(boolean flag){
        model.setTestFlag(flag);
    }
    public void setValidFlag(boolean flag){
        model.setValidFlag(flag);
    }

}
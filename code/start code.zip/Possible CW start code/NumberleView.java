// NumberleView.java
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Observer;
import java.awt.geom.RoundRectangle2D;
public class NumberleView implements Observer {
    private final INumberleModel model;
    private final NumberleController controller;
    private final JFrame frame = new JFrame("Numberle");
    private String inputTextField = "";;
    private final JLabel attemptsLabel = new JLabel("Attempts remaining: ");
    private final JLabel targetLabel = new JLabel("The Target equation: ");
    private final JPanel numberPanel = new JPanel();
    private final JPanel inputPanel = new JPanel();
    private final JPanel expPanel = new JPanel();
    //Restart game button in GUI
    private final JButton startB = new RoundButton("Start New Game",20,20,Color.WHITE);
    private int MAXattempts;
    private int curindex = 0;
    private int curAttempts = 0;

    private final String[] operators = {"+", "-", "*", "/","=","del"};

    public NumberleView(INumberleModel model, NumberleController controller) {//Constructor and initialization
        this.controller = controller;
        this.model = model;
        //Same as the three switches of the model
        model.setRandFlag(true);
        model.setValidFlag(true);
        model.setTestFlag(false);
        this.controller.startNewGame();
        ((NumberleModel)this.model).addObserver(this);
        initializeFrame();
        this.controller.setView(this);
        update((NumberleModel)this.model, null);
    }

    //This method constructs the overall GUI layout and the initial state of each component.
    public void initializeFrame() {
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLayout(new BorderLayout());

        //This section is the layout at the top of the GUI
        JPanel center = new JPanel();
        center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS));

        center.add(new JPanel());
        JPanel textPanel = new JPanel();
        textPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        textPanel.setLayout(new GridLayout(3, 1));
        attemptsLabel.setText("Attempts remaining: " + controller.getRemainingAttempts());
        textPanel.add(attemptsLabel);
        textPanel.add(new JPanel());
        targetLabel.setText("The Target equation: *******");
        textPanel.add(targetLabel);
        textPanel.add(new JPanel());

        startB.setEnabled(false);
        startB.addActionListener(e -> {
            inputTextField = "";
            controller.startNewGame();
            clearFrame();
        });
        textPanel.add(startB);
        textPanel.add(new JPanel());
        center.add(textPanel);
        center.add(new JPanel());
        Font font = new Font("Arial", Font.BOLD, 16);

        //This section is for the input field in the GUI
        MAXattempts = model.getRemainingAttempts();
        int MAXcols = 7;//Equation length is 7
        inputPanel.setLayout(new GridLayout(MAXattempts, MAXcols));
        inputPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        center.add(inputPanel);
        center.add(new JPanel());

        for(int i=0;i<MAXattempts;i++){//Allow users to guess up to 6 inputs
            JPanel line = new JPanel();
            for(int j =0; j<MAXcols;j++){
                JButton emp = new RoundButton("",50,50,Color.WHITE);
                emp.setEnabled(false);
                emp.setPreferredSize(new Dimension(50,50));
                emp.setFont(font);
                line.add(emp);
            }
            inputPanel.add(line);
        }


        JPanel keyboardPanel = new JPanel();
        keyboardPanel.setLayout(new BoxLayout(keyboardPanel, BoxLayout.Y_AXIS));
        keyboardPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        keyboardPanel.add(new JPanel());

        numberPanel.setLayout(new GridLayout(1, 10));
        keyboardPanel.add(numberPanel);

        //This section is the numeric part of the keyboard in GUI
        for (int i = 0; i < 10; i++) {
            JButton button = new RoundButton(Integer.toString(i),50,50,Color.WHITE);
            button.setEnabled(true);
            button.setFocusable(false);
            button.addActionListener(e -> {
                if(curindex == MAXcols)return;
                JButton curb = (JButton) ((JPanel) inputPanel.getComponent(curAttempts)).getComponent(curindex);
                inputTextField += button.getText();
                curindex++;
                curb.setText(button.getText());
                curb.setForeground(Color.DARK_GRAY);
            });
            button.setFont(font);
            numberPanel.add(button);
        }
        keyboardPanel.add(new JPanel());


        expPanel.setLayout(new GridLayout(1, 7));
        keyboardPanel.add(expPanel);

        JButton delbutton = new RoundButton(operators[5],50,50,Color.WHITE);
        delbutton.setEnabled(true);
        delbutton.setFocusable(false);
        delbutton.addActionListener(e -> {
            if (!inputTextField.isEmpty()) {
                inputTextField = inputTextField.substring(0, inputTextField.length() - 1);
                curindex--;
                JButton curb = (JButton) ((JPanel) inputPanel.getComponent(curAttempts)).getComponent(curindex);
                curb.setForeground(Color.DARK_GRAY);
                curb.setText("");
            }else {
                JOptionPane.showMessageDialog(frame, "EMPTY INPUT", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        delbutton.setFont(font);
        expPanel.add(delbutton);

        //This section is for the second row of the keyboard in the GUI: operation buttons
        for (int i = 0; i < 5; i++) {
            JButton button = new RoundButton(operators[i],50,50,Color.WHITE);
            button.setEnabled(true);
            button.setFocusable(false);
            button.addActionListener(e -> {
                if(curindex == MAXcols)return;
                JButton curb = (JButton) ((JPanel) inputPanel.getComponent(curAttempts)).getComponent(curindex);
                inputTextField += button.getText();
                curindex++;
                curb.setForeground(Color.DARK_GRAY);
                curb.setText(button.getText());
            });

            button.setFont(font);

            expPanel.add(button);
        }

        JButton submitButton = new JButton("Submit");
        submitButton.addActionListener(e -> {
            controller.processInput(inputTextField);
        });
        expPanel.add(submitButton);

        frame.add(center, BorderLayout.NORTH);

        frame.add(keyboardPanel, BorderLayout.SOUTH);
        frame.pack(); // Resize the window to fit the new panel
        frame.setVisible(true);


    }
    //This method is used to reinitialize various components to their initial state
    public void clearFrame() {
        for (int i = 0; i < 10; i++) {
            RoundButton tmp = (RoundButton)numberPanel.getComponent(i);
            tmp.setColorB(Color.WHITE);
        }


        for (int i = 0; i < 6; i++) {
            RoundButton tmp= (RoundButton)expPanel.getComponent(i);
            tmp.setColorB(Color.WHITE);
        }

        for (int i =0;i<MAXattempts;i++){
            for (int j=0;j<7;j++){
                RoundButton curb = (RoundButton) ((JPanel) inputPanel.getComponent(i)).getComponent(j);
                curb.setText("");
                curb.setColorB(Color.WHITE);
            }
        }
        startB.setEnabled(false);
        curindex = 0;
        curAttempts = 0;
        inputTextField = "";

        frame.pack(); // Resize the window to fit the new panel
        frame.setVisible(true);


    }

    //This method is used to change the color of the inputted equation
    public void changeButtonColor(StringBuilder curguess){
        StringBuilder sameChars = controller.getSameCharsc();
        StringBuilder diffChars = controller.getDiffCharsc();
        JPanel curPanel;
        for(int i=0;i<curguess.length();i++){
            char ch = curguess.charAt(i);
            int cur_button = 0;
            if (Character.isDigit(ch)){
                curPanel = numberPanel;
                cur_button = ch-'0';
            }else{
                curPanel = expPanel;
                for(int j = 0;j<5;j++) {
                    if (curguess.charAt(i) == operators[j].charAt(0)) {
                        cur_button = j+1;
                        break;
                    }
                }
            }
            RoundButton cur = (RoundButton)curPanel.getComponent(cur_button);
            if(sameChars.indexOf(Character.toString(ch)) != -1 ){
                cur.setColorB(Color.GREEN);
            }else if(diffChars.indexOf(Character.toString(ch)) != -1){
                cur.setColorB(Color.ORANGE);
            }else {
                cur.setColorB(Color.LIGHT_GRAY);
            }
        }
    }

    //This method is used to change the color of the input button
    public void addNewEq(StringBuilder curguess,int curAttempt){
        StringBuilder sameChars = controller.getResChars();

        JPanel curPanel = (JPanel) inputPanel.getComponent(MAXattempts-curAttempt -1);

        for(int i=0;i<curguess.length();i++){
            RoundButton button = (RoundButton) curPanel.getComponent(i);
            button.setEnabled(false);
            button.setPreferredSize(new Dimension(50, 50));
            if(sameChars.charAt(i) == '0'){
                button.setColorB(Color.LIGHT_GRAY);
            }else if(sameChars.charAt(i) == '1'){
                button.setColorB(Color.GREEN);
            }else {
                button.setColorB(Color.ORANGE);
            }
        }
    }
    @Override
    public void update(java.util.Observable o, Object arg) {
        //This method updates the GUI page based on observer listening events

        //Display remaining guesses
        attemptsLabel.setText("Attempts remaining: " + controller.getRemainingAttempts());
        //Obtain the user input equation for the model through the controller
        StringBuilder curguess = controller.getCurrentGuess();
        //According to the switch display target equation
        targetLabel.setText("The Target equation: " + controller.getTargetWord());
        String msg = "";
        if(curguess.isEmpty()){
            msg = controller.getErrMsg();
            if (msg.length() > 0) {
                JOptionPane.showMessageDialog(frame, msg, "Error", JOptionPane.ERROR_MESSAGE);
            }
            return;
        }
        changeButtonColor(curguess);
        addNewEq(curguess, controller.getRemainingAttempts());
        if (controller.isGameOver()) {
            // User confirmation to reinitialize, reinitialize interface
            if(controller.isGameWon()){
                msg ="You win!";
            }else {
                msg = "You lose!";
            }
            JOptionPane.showMessageDialog(frame, msg);
            controller.startNewGame();
            clearFrame();
            return;
        }
        startB.setEnabled(true);//The restart button can only be triggered after the user makes a valid input
        curAttempts ++;
        curindex = 0;
        inputTextField = "";
        frame.pack();
    }
}

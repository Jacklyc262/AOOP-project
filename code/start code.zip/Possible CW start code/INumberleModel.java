import java.util.List;

public interface INumberleModel {
    int MAX_ATTEMPTS = 6;

    void initialize();
    boolean processInput(String input);
    boolean isGameOver();
    boolean isGameWon();
    String getTargetNumber();
    StringBuilder getCurrentGuess();
    int getRemainingAttempts();
    StringBuilder getSameCharsc();
    StringBuilder getDiffCharsc();
    StringBuilder getResChars();

    String getErrmsg();
    void setRandFlag(Boolean randFlag);
    void setTestFlag(Boolean testFlag);
    void setValidFlag(Boolean validFlag);
    void startNewGame();

    StringBuilder compareStrings(String input, String target);

    boolean validateExpression(String expression);
}
import javax.swing.*;
import java.awt.*;

public class RoundButton extends JButton
{
    private String s;
    private int sizeX;
    private int sizeY;

    public void setColorB(Color colorB) {
        this.colorB = colorB;
        super.setBackground(colorB);
    }

    private Color colorB = new Color(255,255,255);

    public RoundButton()
    {
        super("");
        this.sizeX = 50;
        this.sizeY = 50;
        setContentAreaFilled(false);
    }

    public RoundButton(String s ,int sizeX,int sizeY,Color bg)
    {
        super(s);
        this.sizeX = sizeX;
        this.sizeY = sizeY;
        this.colorB = bg;
        setContentAreaFilled(false);
    }

    protected void paintComponent(Graphics g)
    {
        g.setColor(colorB);
        g.fillRoundRect(0,0,getSize().width-1,getSize().height-1,15,15);
        super.paintComponent(g);
    }

    protected void paintBorder(Graphics g)
    {
        g.drawRoundRect(0,0,getSize().width-1,getSize().height-1,15,15);
    }

}

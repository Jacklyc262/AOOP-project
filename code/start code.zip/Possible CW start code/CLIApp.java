import java.util.Scanner;

public class CLIApp {
    public static void main(String[] args) {
        INumberleModel model = new NumberleModel();
        Scanner scanner = new Scanner(System.in);
        System.out.print("Choose the Flag: If you want to open Random Flag, input the letter R,else input  the letter Q\n");
        char letter = scanner.next().charAt(0);
        model.setRandFlag(letter=='R');
        System.out.print("Choose the Flag: If you want to open Test Flag, input the letter T,else input  the letter Q\n");
        letter = scanner.next().charAt(0);
        model.setTestFlag(letter=='T');
        System.out.print("Choose the Flag: If you want to open Valid Flag, input the letter V,else input  the letter Q\n");
        letter = scanner.next().charAt(0);
        model.setValidFlag(letter=='V');
        model.startNewGame();
        String equation = scanner.nextLine();
        while (!model.isGameOver()){
            System.out.print("Current attempt number is "+model.getRemainingAttempts()+"\n");
            System.out.print("Enter an equation: ");
            equation = scanner.nextLine();
            model.processInput(equation);
        }
    }
}

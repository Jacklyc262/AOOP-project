import javax.swing.*;
import java.util.Locale;

public class GUIApp {
    public static void main(String[] args) {
        Locale.setDefault(new Locale("en","US"));
        javax.swing.SwingUtilities.invokeLater(
                new Runnable() {
                    public void run() {
                        createAndShowGUI();
                    }
                }
        );
    }

    public static void createAndShowGUI() {
        INumberleModel model = new NumberleModel();
        NumberleController controller = new NumberleController(model);
        NumberleView view = new NumberleView(model, controller);
    }
}
// NumberleModel.java
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class NumberleModel extends Observable implements INumberleModel {
    //@ public invariant \invariant_for(targetNumber);
    //@ invariant remainingAttempts >= 0 && remainingAttempts <=6;
    private String targetNumber; //Target Equation
    private StringBuilder currentGuess;
    private int remainingAttempts; //User's remaining guesses
    private boolean gameWon;
    //sameCharsc is used to represent the current and fully guessed character set
    private StringBuilder sameCharsc= new StringBuilder();

    //diffCharsc is used to represent the set of characters that have been guessed incorrectly so far
    private StringBuilder diffCharsc= new StringBuilder();

    //unuseCharsc represents a set of characters that have not been used so far
    private StringBuilder unuseCharsc= new StringBuilder("0123456789+-*/=");

    //useCharsc represents the set of characters that have been used so far
    private StringBuilder useCharsc= new StringBuilder();

    //ResChars represents the match between the user's input equation and the target equation.
    //0 means not match, 1 means match the right position, 2 means match the wrong position.
    private StringBuilder resCharsc;
    private Boolean validFlag = true; //equation verification switch
    private Boolean testFlag = true; //equation display switch
    private Boolean randFlag = true; //equation random switch

    private String errmsg = "";//error message


    @Override
    public void initialize() {//Game initialization
        if(randFlag){
            targetNumber = readFile("equations.txt");
        }else {
            targetNumber = "1*3+4=7";//Default Equation
        }
        if(testFlag){
            System.out.print("The equation is " + targetNumber+"\n");
        }
        errmsg = "";
        currentGuess = new StringBuilder();
        remainingAttempts = MAX_ATTEMPTS;
        gameWon = false;
        sameCharsc = new StringBuilder();
        diffCharsc = new StringBuilder();
        unuseCharsc = new StringBuilder("0123456789+-*/=");
        useCharsc = new StringBuilder();
        setChanged();
        notifyObservers();
    }

    //@ invariant remainingAttempts >= 0 && remainingAttempts <=6;
    //@ requires input != null;
    //@ ensures \result ==> \result && !\result ==> errmsg != null;
    @Override
    public boolean processInput(String input) {
        assert remainingAttempts >= 0 && remainingAttempts <=6;
        System.out.println(input);
        boolean ans = false;//Record whether the input is valid (length is valid and equation is correct)
        assert input != null;
        if(input.length() != getTargetNumber().length()){//Check the length of the input equation
            errmsg ="invalid length!";
            currentGuess = new StringBuilder();
            System.out.println(errmsg);
        }else{
            remainingAttempts--;
            if (validFlag && !validateExpression(input)){
                //If the equality check switch is turned on and the input is an invalid equation,
                //then this input is not counted towards the number of guesses.
                remainingAttempts++;
                currentGuess = new StringBuilder();
                //// Notify that this input is invalid
                System.out.println(errmsg);

            }else{
                // Change color
                resCharsc = compareStrings(input,targetNumber);
                currentGuess = new StringBuilder(input);
                if (input.equals(targetNumber)){//input the right equation
                    gameWon = true;
                    System.out.println("You win!");
                }
                ans = true;
            }

        }
        setChanged();
        notifyObservers();
        return ans; //If the input is a valid equation, return true
    }

    @Override
    public boolean isGameOver() {
        return remainingAttempts <= 0 || gameWon;
    }

    @Override
    public boolean isGameWon() {
        return gameWon;
    }

    @Override
    public String getTargetNumber() {
        //Return encrypted or unencrypted equation based on switch status
        if(testFlag) {
            return targetNumber;
        }
        return "*******";
    }

    @Override
    public StringBuilder getCurrentGuess() {
        return currentGuess;
    }

    @Override
    public int getRemainingAttempts() {
        return remainingAttempts;
    }

    @Override
    public void startNewGame() {
        initialize();
    }

    //@ ensures \result != null;
    public StringBuilder getSameCharsc() {
        return sameCharsc;
    }

    //@ ensures \result != null;
    public StringBuilder getDiffCharsc() {
        return diffCharsc;
    }
    //@ ensures \result != null;
    public StringBuilder getResChars() {
        return resCharsc;
    }
    public void setValidFlag(Boolean validFlag) {
        this.validFlag = validFlag;
    }

    public void setTestFlag(Boolean testFlag) {
        this.testFlag = testFlag;
    }

    public void setRandFlag(Boolean randFlag) {
        this.randFlag = randFlag;
    }

    //@ requires filePath != null;
    //@ ensures \result != null;
    private String readFile(String filePath) {//method for Reading File
        assert filePath != null;
        List<String> lines = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (lines.isEmpty()) {
            System.out.println("File is empty or could not be read.");
            return null;
        }
        int cur = new Random().nextInt(0,lines.size());
        return lines.get(cur);
    }

    //@ requires expression != null;
    //@ ensures \result ==> \result && !\result ==> errmsg != null;
    public boolean validateExpression(String expression) {
        //This method calculates the result of an equation and verifies its validity
        assert expression != null;
        //Using Stacks to Implement Mathematical Calculations
        //One stack is used to hold numbers, and the other is used to hold operators
        Stack<Double> numbers = new Stack<>();
        Stack<Character> operators = new Stack<>();
        boolean hasEquals = false;

        for (int i = 0; i < expression.length(); i++) {//Traverse the entire equation
            char ch = expression.charAt(i);
            if (Character.isDigit(ch)) {
                double num = ch - '0';//Convert characters to numbers
                //If a number is read continuously, it indicates that the number is a multi digit number
                while (i + 1 < expression.length() && Character.isDigit(expression.charAt(i + 1))) {
                    num = num * 10 + (expression.charAt(++i) - '0');
                }
                numbers.push(num);
            } else if (ch == '+' || ch == '-' || ch == '*' || ch == '/') {
                //If the operator has already been read before and the operator currently read has a lower priority,
                //perform one operation on the previous operator and number.
                while (!operators.isEmpty() && precedence(ch) <= precedence(operators.peek())) {
                    if(!processOperator(numbers, operators)){
                        return false;//Equation incorrect
                    }
                }
                operators.push(ch);//Store new operators on the stack
            } else if (ch == '=') {
                if (hasEquals) {
//                    System.out.println("More than one equals sign in the expression.");
                    errmsg = "More than one equals sign in the expression.";
                    return false;
                }
                hasEquals = true;
                //Operate continuously until there are no remaining operators in the operator stack
                while (!operators.isEmpty()) {
                    if(!processOperator(numbers, operators)){
                        return false;
                    }
                }
            }else {//Invalid character read
                errmsg = "Invalid letter in the expression.";
                return false;
            }
        }

        //Check the equation after calculation
        if (!hasEquals) {
            errmsg = "No equals sign in the expression.";
            return false;
        }else {
            while (!operators.isEmpty()) {
                if(!processOperator(numbers, operators)){
                    return false;
                }
            }
        }


        if (numbers.isEmpty() || !operators.isEmpty()) {
            errmsg = "Invalid expression format.";
            return false;
        }
        //According to processOperator(),
        //the numbers stack will have two numbers, representing the calculation results on both sides of the equation.
        double result1 = numbers.pop();
        //After retrieving the first result, there should be one number left on the stack
        if (numbers.isEmpty()) {
            errmsg = "Invalid expression format.";
            return false;
        }
        double result2 = numbers.pop();
        //After retrieving the second result, the stack should be empty
        if (!numbers.isEmpty()) {
            errmsg = "Invalid expression format.";
            return false;
        }
        if(result1 != result2){//The two sides of the equation are not equal
            errmsg = "left side doesn't equal right side!";
            return false;
        }
        return true;//No abnormalities occurred
    }



    private boolean processOperator(Stack<Double> numbers, Stack<Character> operators) {
        //If the operator stack or number stack is empty, the calculation cannot be performed.
        if (numbers.size() == 0 || operators.size() == 0){
            errmsg = " The first two characters of the equation have no digits ";
            return false;
        }
        char op = operators.pop();//get operator
        double num2 = numbers.pop();//get first number
        //If there are still numbers on the stack, get another number
        double num1 = numbers.empty() ? 0 : numbers.pop();
        double result = 0;
        switch (op) {//calculate
            case '+':
                result = num1 + num2;
                break;
            case '-':
                result = num1 - num2;
                break;
            case '*':
                result = num1 * num2;
                break;
            case '/':
                if (num2 == 0) {//Cannot be 0 after division
                    errmsg = "Division by zero is not allowed.";
                    return false;
                }
                result = num1 / num2;
                break;
        }
        numbers.push(result);
        return true;
    }


    private static int precedence(char op) {
        switch (op) {
            case '+':
            case '-':
                return 1;//Addition and subtraction have low priority
            case '*':
            case '/':
                return 2;//Multiplication and division have high priority
            default:
                return 0;
        }
    }

    //@ requires input != null && targetNumber != null;
    //@ requires input.length() == targetNumber.length();
    //@ ensures \result != null;
    //This method is used to determine whether the input equation is consistent with the target equation
    public StringBuilder compareStrings(String input, String targetNumber) {
        assert input != null && targetNumber != null && input.length() == targetNumber.length();

        //Using arrays to record the match between input and target equations
        //0 means not match, 1 means match the right position, 2 means match the wrong position.
        StringBuilder resChars = new StringBuilder();
        int[] matchFlags = new int[targetNumber.length()];

        // Initialize array
        Arrays.fill(matchFlags, 0);

        // Traverse each character of the input and find a match in the target
        for (int i = 0; i < input.length(); i++) {
            char currentChar = input.charAt(i);
            if (targetNumber.charAt(i) == currentChar){
                matchFlags[i]=1;
                resChars.append('1');
                //If the character does not appear in sameCharsc, add it.
                if(sameCharsc.indexOf(Character.toString(currentChar)) == -1){
                    sameCharsc.append(currentChar);
                }
                //If the character appears in diffCharsc, delete it
                int dindex = diffCharsc.indexOf(Character.toString(currentChar));
                if(dindex != -1){
                    diffCharsc.deleteCharAt(dindex);
                }
            }else{//The character was not found in the target equation
                resChars.append('0');
            }
        }


        for (int i = 0; i < input.length(); i++) {
            char currentChar = input.charAt(i);
            // Find the current character from the starting position of the target
            if (targetNumber.charAt(i) != currentChar) {
                for (int j = 0; j < targetNumber.length(); j++) {
                    if (targetNumber.charAt(j) == currentChar && matchFlags[j] == 0) {
                        // Found matching characters that have not been marked
                        resChars.setCharAt(i, '2');
                        if (sameCharsc.indexOf(Character.toString(currentChar)) == -1 &&
                                diffCharsc.indexOf(Character.toString(currentChar)) == -1) {
                            diffCharsc.append(currentChar);
                        }
                        matchFlags[j] = 1; // Mark as matched
                        break;
                    }
                }
            }
            if(useCharsc.indexOf(Character.toString(currentChar)) == -1 && unuseCharsc.indexOf(Character.toString(currentChar))!= -1) {
                useCharsc.append(currentChar);
                unuseCharsc.deleteCharAt(unuseCharsc.indexOf(Character.toString(currentChar)));
            }
        }

        //Present the current guess situation
        System.out.println("0 means not match, 1 means match the right position, 2 means match the wrong position");
        System.out.println("Current equation status:" + resChars);
        System.out.println("Unused characters: " + unuseCharsc);
        System.out.println("Used characters: " + useCharsc);
        System.out.println("Same characters at same position: " + sameCharsc);
        System.out.println("Characters appeared at different positions: " + diffCharsc);
        return resChars;
    }

    //@ ensures \result != null;
        public String getErrmsg(){
        return errmsg;
    }
}





